import{a as t}from"../chunks/entry.Bs7YLkvK.js";export{t as start};
